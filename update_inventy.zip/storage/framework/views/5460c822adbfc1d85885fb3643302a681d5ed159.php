<?php $__env->startSection('top'); ?>
    <style>
        /* Container style */
        .container {
            max-width: 1200px; /* Adjust the maximum width as needed */
            margin: 0 auto; /* Center the container */
            padding: 20px; /* Add some padding for better readability */
        }

        /* Row style */
        .row {
            display: flex;
            flex-wrap: wrap;
            margin: -10px; /* Adjust margin to create space between kolumns */
        }

        /* kolumn style */
        .kol {
            box-sizing: border-box;
            flex: 1;
            padding: 10px; /* Adjust padding to create space between kolumns */
        }

        /* Example styling for specific kolumn widths */
        .kol-1 { flex-basis: calc(8.333% - 20px); }
        .kol-2 { flex-basis: calc(16.667% - 20px); }
        .kol-3 { flex-basis: calc(25% - 20px); }
        .kol-4 { flex-basis: calc(33.333% - 20px); }
        .kol-5 { flex-basis: calc(41.667% - 20px); }
        .kol-6 { flex-basis: calc(50% - 20px); }
        .kol-7 { flex-basis: calc(58.333% - 20px); }
        .kol-8 { flex-basis: calc(66.667% - 20px); }
        .kol-9 { flex-basis: calc(75% - 20px); }
        .kol-10 { flex-basis: calc(83.333% - 20px); }
        .kol-11 { flex-basis: calc(91.667% - 20px); }
        .kol-12 { flex-basis: calc(100% - 20px); }

        /* Responsive styles (adjust as needed) */
        @media (max-width: 768px) {
            .kol {
                flex-basis: calc(100% - 20px); /* Full width on smaller screens */
            }
        }

        .bg-white {
            background: #fff;
        }

        .p-1 {
            padding: 1rem;
        }

        .p-2 {
            padding: 2rem;
        }

        .p-3 {
            padding: 3rem;
        }

        .p-4 {
            padding: 4rem;
        }

        .p-5 {
            padding: 5rem;
        }

        .shadow-sm {
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            background-kolor: #ffffff;
            border-radius: 8px;
            }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php 
$mysqli = new mysqli("localhost", "root", "", "inventory2");
if($mysqli->connect_error) {
  exit('Error connecting to database');
}
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$mysqli->set_charset("utf8mb4");    
?>
    <div>

        <div class="box-header">
            <h3 class="box-title">Profil <?php echo e(\Auth::user()->name); ?></h3>
        </div>

        <!-- /.box-header -->
        <div class="box-body">
            <div class="row">
                <div class="kol-12">
                    <div class="row">
                        <div class="kol-4 p-2">
                            <div class="bg-white shadow-sm p-2">
                                <div class="form-group">
                                    <img src="https://localhost/user.png" style="width: 100%">
                                </div>
                            </div>
                        </div>
                        <div class="kol-8 p-2">
                            <div class="bg-white shadow-sm p-2">
                                <div class="form-group">
                                    <label>Nama Lengkap</label>
                                    <input type="text" disabled value="<?php echo e(\Auth::user()->name); ?>" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Alamat Email</label>
                                    <input type="text" disabled value="<?php echo e(\Auth::user()->email); ?>" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Role</label>
                                    <input type="text" disabled value="<?php echo e(\Auth::user()->role); ?>" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.box-body -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('bot'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>